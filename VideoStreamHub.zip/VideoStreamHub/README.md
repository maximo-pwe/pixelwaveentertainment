# CloudTube - Plataforma de Videos tipo YouTube

Una aplicación completa de videos similar a YouTube construida con React, Express y Firebase. Incluye autenticación con Google, reproducción de videos desde la nube, sistema de comentarios y personalización de canales.

## 🚀 Características

### ✅ Autenticación
- Inicio de sesión con Google (Firebase)
- Modo invitado sin registro
- Gestión automática de sesiones

### ✅ Gestión de Videos
- Reproducción desde URLs de la nube
- Contador de visualizaciones automático
- Sistema de likes y dislikes
- Miniaturas personalizadas
- Información de duración

### ✅ Sistema de Comentarios
- Comentarios en tiempo real
- Información del usuario autor
- Contador de likes por comentario
- Interfaz intuitiva para agregar comentarios

### ✅ Canales Personalizables
- Avatar personalizado
- Nombre y descripción del canal
- Configuración completa del perfil
- Gestión de videos del canal

### ✅ Interfaz Moderna
- Diseño oscuro inspirado en YouTube
- Completamente responsive
- Sidebar navegable
- Player de video con controles completos

## 🛠️ Tecnologías

- **Frontend**: React 18, TypeScript, TailwindCSS
- **Backend**: Express.js, Node.js
- **Base de Datos**: Almacenamiento en memoria (sin dependencias)
- **Autenticación**: Firebase Auth
- **Routing**: Wouter
- **Estado**: TanStack Query
- **UI Components**: Radix UI + shadcn/ui
- **Deployment**: Netlify Functions

## 📦 Instalación y Desarrollo

### Prerrequisitos
- Node.js 20+
- npm o yarn

### Configuración Local

1. **Clona el repositorio**
```bash
git clone <tu-repositorio>
cd cloudtube
```

2. **Instala dependencias**
```bash
npm install
```

3. **Configura variables de entorno**
Crea un archivo `.env` con:
```
VITE_FIREBASE_API_KEY=tu_api_key
VITE_FIREBASE_APP_ID=tu_app_id  
VITE_FIREBASE_PROJECT_ID=tu_project_id
```

4. **Inicia el servidor de desarrollo**
```bash
npm run dev
```

## 🌐 Despliegue en Netlify

### Configuración Automática

El proyecto incluye configuración completa para Netlify:

- `netlify.toml` - Configuración de build
- `netlify/functions/api.ts` - API serverless
- `_redirects` - Redirecciones SPA

### Pasos de Despliegue

1. **Conecta tu repositorio a Netlify**
2. **Configura variables de entorno** en el panel de Netlify
3. **Deploy automático** con cada push

### Variables de Entorno Requeridas

```
VITE_FIREBASE_API_KEY=tu_firebase_api_key
VITE_FIREBASE_APP_ID=tu_firebase_app_id
VITE_FIREBASE_PROJECT_ID=tu_firebase_project_id
```

## 🔧 Configuración de Firebase

### 1. Crear Proyecto Firebase
1. Ve a [Firebase Console](https://console.firebase.google.com/)
2. Crea un nuevo proyecto
3. Añade una aplicación web

### 2. Configurar Autenticación
1. Habilita Authentication
2. Activa el proveedor de Google
3. Añade dominios autorizados:
   - `localhost` (desarrollo)
   - Tu dominio de Netlify (producción)

### 3. Obtener Credenciales
En la configuración de tu app, copia:
- API Key
- App ID  
- Project ID

## 📁 Estructura del Proyecto

```
├── client/src/           # Aplicación React
│   ├── components/       # Componentes UI
│   ├── pages/           # Páginas principales
│   ├── lib/             # Utilidades y configuración
│   └── hooks/           # Custom hooks
├── server/              # Backend Express (desarrollo)
├── shared/              # Esquemas y tipos compartidos
├── netlify/functions/   # Funciones serverless
├── netlify.toml        # Configuración Netlify
└── package.json        # Dependencias
```

## 🎥 Gestión de Videos

### Almacenamiento en la Nube

La aplicación soporta videos desde servicios de almacenamiento:

- **Cloudinary** - Recomendado para procesamiento automático
- **AWS S3** - Escalable y confiable
- **Google Cloud Storage** - Integración con Firebase
- **Azure Blob Storage** - Para ecosistema Microsoft

### Subir Videos

1. Sube tu video a un servicio de almacenamiento
2. Obtén la URL pública del video
3. Usa el modal "Subir Video" en la aplicación
4. Completa título, descripción y URL

## 🎨 Personalización

### Temas y Colores

Los colores están definidos en `client/src/index.css`:

```css
:root {
  --youtube-red: hsl(0, 100%, 50%);
  --youtube-dark: hsl(240, 10%, 3.9%);
  --youtube-gray: hsl(240, 3.7%, 15.9%);
}
```

### Componentes UI

Todos los componentes usan la biblioteca shadcn/ui y son completamente personalizables.

## 🚀 Características Avanzadas

### Sin Base de Datos

- Funciona completamente en memoria
- No requiere configuración de BD
- Ideal para demos y prototipos
- Datos se reinician con cada deploy

### Responsive Design

- Optimizado para móviles
- Sidebar colapsable
- Player de video adaptativo
- Interfaz táctil amigable

### SEO Ready

- Meta tags apropiados
- Routing client-side
- URLs amigables
- Optimización de performance

## 📝 API Endpoints

### Videos
- `GET /api/videos` - Lista todos los videos
- `GET /api/videos/:id` - Video específico
- `POST /api/videos` - Crear nuevo video

### Usuarios
- `POST /api/users` - Crear/obtener usuario

### Canales  
- `GET /api/channels/user/:userId` - Canal del usuario
- `PUT /api/channels/:id` - Actualizar canal

### Comentarios
- `GET /api/videos/:id/comments` - Comentarios del video
- `POST /api/comments` - Nuevo comentario

## 🐛 Solución de Problemas

### Error de Firebase
- Verifica que las variables de entorno estén configuradas
- Confirma que el dominio esté en la lista autorizada
- Revisa la configuración del proyecto Firebase

### Error de Build
- Ejecuta `npm run build` localmente para verificar
- Revisa logs de Netlify para errores específicos
- Confirma que todas las dependencias estén instaladas

### Videos no se reproducen
- Verifica que la URL del video sea pública
- Confirma que el formato sea compatible (MP4 recomendado)
- Revisa CORS del servicio de almacenamiento

## 📄 Licencia

MIT License - Libre para uso personal y comercial.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

---

**CloudTube** - Una experiencia de video completa y moderna para la web.