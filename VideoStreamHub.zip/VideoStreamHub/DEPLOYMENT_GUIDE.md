# CloudTube - Guía de Despliegue en Netlify

## Características de la Aplicación

- ✅ Interfaz similar a YouTube con diseño oscuro
- ✅ Autenticación con Google (Firebase)
- ✅ Inicio de sesión como invitado
- ✅ Reproducción de videos desde URLs de la nube
- ✅ Sistema de comentarios
- ✅ Personalización de canales (foto, nombre, descripción)
- ✅ Subida de videos (preparado para integración con servicios de almacenamiento)
- ✅ Responsive design

## Pasos para el Despliegue

### 1. Configuración de Firebase (Opcional)

Si quieres usar autenticación con Google:

1. Ve a [Firebase Console](https://console.firebase.google.com/)
2. Crea un nuevo proyecto
3. Añade una app web
4. Habilita autenticación con Google
5. Añade tu dominio de Netlify a dominios autorizados
6. Obtén las claves de configuración

### 2. Variables de Entorno en Netlify

En el panel de Netlify, configura estas variables:

```
VITE_FIREBASE_API_KEY=tu_api_key
VITE_FIREBASE_APP_ID=tu_app_id  
VITE_FIREBASE_PROJECT_ID=tu_project_id
```

### 3. Configuración de Build

El archivo `netlify.toml` ya está configurado:

- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`

### 4. Despliegue

1. Conecta tu repositorio a Netlify
2. Las variables de entorno se configuran automáticamente
3. El build se ejecuta automáticamente
4. La aplicación estará disponible en tu dominio de Netlify

## Estructura del Proyecto

```
├── client/src/           # Frontend React
├── server/              # Backend Express (para desarrollo)
├── shared/              # Esquemas compartidos
├── netlify/functions/   # Funciones serverless para producción
├── netlify.toml        # Configuración de Netlify
└── package.json        # Dependencias
```

## Funcionalidades

### Autenticación
- Google Sign-In con Firebase
- Modo invitado sin registro

### Videos
- Reproducción desde URLs de la nube
- Contador de visualizaciones
- Sistema de likes/dislikes
- Comentarios en tiempo real

### Canales
- Personalización completa
- Avatar y descripción
- Gestión de videos del canal

## Almacenamiento de Videos

La aplicación está preparada para integrarse con servicios de almacenamiento en la nube:

- **Cloudinary**: Para almacenamiento y procesamiento
- **AWS S3**: Para almacenamiento escalable  
- **Google Cloud Storage**: Integración con Firebase
- **Azure Blob Storage**: Para usuarios de Microsoft

Solo necesitas configurar las URLs de los videos en el campo `cloudUrl`.

## Notas Técnicas

- Funciona sin base de datos (usa almacenamiento en memoria)
- Compatible con Netlify Functions
- Optimizado para dispositivos móviles
- Sin dependencias de Replit