import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { SiYoutube, SiGoogle } from "react-icons/si";
import { User, X } from "lucide-react";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGoogleSignIn: () => void;
  onGuestSignIn: () => void;
}

export default function LoginModal({ isOpen, onClose, onGoogleSignIn, onGuestSignIn }: LoginModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,15.9%)] text-white max-w-sm">
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="absolute top-4 right-4 text-[hsl(0,0%,66.7%)] hover:text-white"
        >
          <X className="h-5 w-5" />
        </Button>

        <div className="text-center mb-6 pt-4">
          <SiYoutube className="text-red-600 text-4xl mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Iniciar Sesión</h2>
          <p className="text-[hsl(0,0%,66.7%)]">Accede a tu cuenta para subir videos</p>
        </div>

        <div className="space-y-4">
          <Button
            onClick={onGoogleSignIn}
            className="w-full flex items-center justify-center space-x-3 bg-white hover:bg-gray-100 text-black py-3"
          >
            <SiGoogle className="h-5 w-5" />
            <span>Continuar con Google</span>
          </Button>

          <div className="text-center">
            <span className="text-[hsl(0,0%,66.7%)]">o</span>
          </div>

          <Button
            onClick={onGuestSignIn}
            variant="secondary"
            className="w-full bg-[hsl(240,3.7%,15.9%)] hover:bg-gray-600 text-white py-3 flex items-center justify-center space-x-3"
          >
            <User className="h-5 w-5" />
            <span>Continuar como Invitado</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
