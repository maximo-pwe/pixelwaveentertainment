import { Card } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

interface Video {
  id: number;
  title: string;
  description?: string;
  thumbnail?: string;
  cloudUrl: string;
  views: number;
  duration?: string;
  createdAt: Date;
  channel: {
    id: number;
    name: string;
    avatar?: string;
  } | null;
}

interface VideoCardProps {
  video: Video;
  onVideoClick?: (video: Video) => void;
}

export default function VideoCard({ video, onVideoClick }: VideoCardProps) {
  const formatViews = (views: number): string => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K`;
    }
    return views.toString();
  };

  const handleClick = () => {
    onVideoClick?.(video);
  };

  return (
    <Card 
      className="bg-[hsl(39,6%,15.3%)] border-[hsl(39,6%,15.3%)] hover:bg-[hsl(39,6%,20%)] transition-colors cursor-pointer overflow-hidden"
      onClick={handleClick}
    >
      <div className="relative">
        <img 
          src={video.thumbnail || "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450"} 
          alt={video.title}
          className="w-full h-48 object-cover"
        />
        {video.duration && (
          <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
            {video.duration}
          </div>
        )}
      </div>
      
      <div className="p-3">
        <div className="flex space-x-3">
          <img 
            src={video.channel?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&face"} 
            alt={video.channel?.name || "Canal"}
            className="w-9 h-9 rounded-full object-cover flex-shrink-0"
          />
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-white text-sm line-clamp-2 mb-1" title={video.title}>
              {video.title}
            </h3>
            <p className="text-[hsl(0,0%,66.7%)] text-xs mb-1">
              {video.channel?.name || "Canal desconocido"}
            </p>
            <p className="text-[hsl(0,0%,66.7%)] text-xs">
              {formatViews(video.views)} visualizaciones • {formatDistanceToNow(new Date(video.createdAt), { addSuffix: true, locale: es })}
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
}
