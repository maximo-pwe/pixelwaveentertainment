import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { CloudUpload, X, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  userChannelId?: number;
}

export default function UploadModal({ isOpen, onClose, userChannelId }: UploadModalProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [cloudUrl, setCloudUrl] = useState("");
  const [thumbnail, setThumbnail] = useState("");
  const [duration, setDuration] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Create video mutation
  const createVideoMutation = useMutation({
    mutationFn: async (videoData: any) => {
      const response = await apiRequest("POST", "/api/videos", videoData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Video subido exitosamente",
        description: "Tu video está ahora disponible en la plataforma",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      handleClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo subir el video",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Error",
        description: "El título es requerido",
        variant: "destructive",
      });
      return;
    }

    if (!cloudUrl.trim()) {
      toast({
        title: "Error",
        description: "La URL del video es requerida",
        variant: "destructive",
      });
      return;
    }

    if (!userChannelId) {
      toast({
        title: "Error",
        description: "Debes iniciar sesión para subir videos",
        variant: "destructive",
      });
      return;
    }

    createVideoMutation.mutate({
      channelId: userChannelId,
      title: title.trim(),
      description: description.trim() || undefined,
      cloudUrl: cloudUrl.trim(),
      thumbnail: thumbnail.trim() || undefined,
      duration: duration.trim() || undefined,
    });
  };

  const handleClose = () => {
    if (!createVideoMutation.isPending) {
      setTitle("");
      setDescription("");
      setCloudUrl("");
      setThumbnail("");
      setDuration("");
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,15.9%)] text-white max-w-md">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-xl font-semibold">Subir Video</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="text-[hsl(0,0%,66.7%)] hover:text-white"
              disabled={createVideoMutation.isPending}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Video URL Input */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="cloudUrl" className="text-sm font-medium">
                URL del video en la nube *
              </Label>
              <Input
                id="cloudUrl"
                type="url"
                value={cloudUrl}
                onChange={(e) => setCloudUrl(e.target.value)}
                placeholder="https://ejemplo.com/mi-video.mp4"
                className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                disabled={createVideoMutation.isPending}
                required
              />
              <p className="text-xs text-[hsl(0,0%,66.7%)] mt-1">
                Sube tu video a un servicio como Cloudinary, AWS S3, o Google Cloud Storage
              </p>
            </div>

            <div>
              <Label htmlFor="title" className="text-sm font-medium">
                Título del video *
              </Label>
              <Input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Introduce el título..."
                className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                disabled={createVideoMutation.isPending}
                required
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-sm font-medium">
                Descripción
              </Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe tu video..."
                rows={3}
                className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                disabled={createVideoMutation.isPending}
              />
            </div>

            <div>
              <Label htmlFor="thumbnail" className="text-sm font-medium">
                Miniatura (URL)
              </Label>
              <Input
                id="thumbnail"
                type="url"
                value={thumbnail}
                onChange={(e) => setThumbnail(e.target.value)}
                placeholder="https://ejemplo.com/miniatura.jpg"
                className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                disabled={createVideoMutation.isPending}
              />
            </div>

            <div>
              <Label htmlFor="duration" className="text-sm font-medium">
                Duración
              </Label>
              <Input
                id="duration"
                type="text"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="15:30"
                className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                disabled={createVideoMutation.isPending}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button
              type="button"
              variant="secondary"
              className="flex-1 bg-[hsl(240,3.7%,15.9%)] hover:bg-gray-600 text-white"
              onClick={handleClose}
              disabled={createVideoMutation.isPending}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
              disabled={createVideoMutation.isPending || !title.trim() || !cloudUrl.trim()}
            >
              {createVideoMutation.isPending ? "Subiendo..." : "Subir Video"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
