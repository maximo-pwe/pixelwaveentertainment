import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { X, Camera } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId?: number;
}

interface Channel {
  id: number;
  name: string;
  description?: string;
  avatar?: string;
}

export default function ChannelModal({ isOpen, onClose, userId }: ChannelModalProps) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [avatar, setAvatar] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user's channel
  const { data: channel, isLoading } = useQuery<Channel>({
    queryKey: ["/api/channels/user", userId],
    enabled: isOpen && !!userId,
  });

  // Update channel mutation
  const updateChannelMutation = useMutation({
    mutationFn: async (updates: Partial<Channel>) => {
      if (!channel) throw new Error("No channel found");
      const response = await apiRequest("PUT", `/api/channels/${channel.id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Canal actualizado",
        description: "Los cambios se han guardado exitosamente",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/channels/user", userId] });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudieron guardar los cambios",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (channel) {
      setName(channel.name || "");
      setDescription(channel.description || "");
      setAvatar(channel.avatar || "");
    }
  }, [channel]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Error",
        description: "El nombre del canal es requerido",
        variant: "destructive",
      });
      return;
    }

    updateChannelMutation.mutate({
      name: name.trim(),
      description: description.trim(),
      avatar: avatar.trim() || undefined,
    });
  };

  const handleClose = () => {
    if (!updateChannelMutation.isPending) {
      onClose();
    }
  };

  if (!userId) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,15.9%)] text-white max-w-md">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-xl font-semibold">Configurar Canal</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="text-[hsl(0,0%,66.7%)] hover:text-white"
              disabled={updateChannelMutation.isPending}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-2"></div>
              <p className="text-sm text-[hsl(0,0%,66.7%)]">Cargando canal...</p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Channel Avatar */}
            <div className="text-center">
              <img
                src={avatar || channel?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&face"}
                alt="Channel avatar"
                className="w-20 h-20 rounded-full object-cover mx-auto mb-4"
              />
              <Button
                type="button"
                variant="link"
                className="text-blue-400 hover:text-blue-300 text-sm flex items-center mx-auto"
                disabled={updateChannelMutation.isPending}
              >
                <Camera className="h-4 w-4 mr-1" />
                Cambiar foto del canal
              </Button>
            </div>

            {/* Channel Details */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="channelName" className="text-sm font-medium">
                  Nombre del canal
                </Label>
                <Input
                  id="channelName"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nombre del canal"
                  className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                  disabled={updateChannelMutation.isPending}
                  required
                />
              </div>

              <div>
                <Label htmlFor="channelDescription" className="text-sm font-medium">
                  Descripción del canal
                </Label>
                <Textarea
                  id="channelDescription"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe tu canal..."
                  rows={3}
                  className="bg-[hsl(240,3.7%,15.9%)] border-[hsl(240,3.7%,15.9%)] text-white focus:border-blue-600"
                  disabled={updateChannelMutation.isPending}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <Button
                type="button"
                variant="secondary"
                className="flex-1 bg-[hsl(240,3.7%,15.9%)] hover:bg-gray-600 text-white"
                onClick={handleClose}
                disabled={updateChannelMutation.isPending}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                disabled={updateChannelMutation.isPending || !name.trim()}
              >
                {updateChannelMutation.isPending ? "Guardando..." : "Guardar Cambios"}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
