import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Menu, Search, Video, Bell } from "lucide-react";
import { SiYoutube, SiGoogle } from "react-icons/si";

interface HeaderProps {
  onMenuToggle: () => void;
  onLoginClick: () => void;
  onUploadClick: () => void;
  user: any;
}

export default function Header({ onMenuToggle, onLoginClick, onUploadClick, user }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Searching for:", searchQuery);
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-[hsl(240,10%,3.9%)] border-b border-[hsl(240,3.7%,15.9%)] z-50 h-14">
      <div className="flex items-center justify-between px-4 h-full">
        {/* Logo and Menu */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuToggle}
            className="text-white hover:bg-[hsl(240,3.7%,15.9%)]"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center space-x-2">
            <SiYoutube className="text-red-600 text-2xl" />
            <span className="text-xl font-bold text-white hidden sm:block">CloudTube</span>
          </div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-8 hidden md:block">
          <div className="flex">
            <Input
              type="text"
              placeholder="Buscar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,15.9%)] rounded-l-full px-4 py-2 text-white focus:border-blue-600"
            />
            <Button
              type="submit"
              className="bg-[hsl(240,3.7%,15.9%)] border border-l-0 border-[hsl(240,3.7%,15.9%)] rounded-r-full px-6 py-2 hover:bg-gray-600"
            >
              <Search className="h-4 w-4 text-white" />
            </Button>
          </div>
        </form>

        {/* User Actions */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onUploadClick}
            className="text-white hover:bg-[hsl(240,3.7%,15.9%)]"
          >
            <Video className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-[hsl(240,3.7%,15.9%)]"
          >
            <Bell className="h-5 w-5" />
          </Button>
          
          {user ? (
            <div className="flex items-center space-x-2">
              <img
                src={user.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40&face"}
                alt="Avatar"
                className="w-8 h-8 rounded-full object-cover"
              />
              <span className="text-white text-sm hidden sm:block">{user.name}</span>
            </div>
          ) : (
            <Button
              onClick={onLoginClick}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <SiGoogle className="h-4 w-4" />
              <span className="hidden sm:block">Iniciar Sesión</span>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
