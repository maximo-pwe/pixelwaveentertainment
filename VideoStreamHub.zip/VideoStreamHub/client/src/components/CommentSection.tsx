import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ThumbsUp } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Comment {
  id: number;
  content: string;
  likes: number;
  createdAt: Date;
  user: {
    id: number;
    name: string;
    avatar?: string;
  } | null;
}

interface CommentSectionProps {
  videoId: number;
  currentUserId?: number;
}

export default function CommentSection({ videoId, currentUserId }: CommentSectionProps) {
  const [newComment, setNewComment] = useState("");
  const [isCommenting, setIsCommenting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch comments
  const { data: comments, isLoading } = useQuery<Comment[]>({
    queryKey: ["/api/videos", videoId, "comments"],
  });

  // Add comment mutation
  const addCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!currentUserId) throw new Error("User not authenticated");
      const response = await apiRequest("POST", "/api/comments", {
        videoId,
        userId: currentUserId,
        content,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos", videoId, "comments"] });
      setNewComment("");
      setIsCommenting(false);
      toast({
        title: "Comentario añadido",
        description: "Tu comentario se ha publicado exitosamente",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo publicar el comentario",
        variant: "destructive",
      });
    },
  });

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newComment.trim()) {
      toast({
        title: "Error",
        description: "El comentario no puede estar vacío",
        variant: "destructive",
      });
      return;
    }

    if (!currentUserId) {
      toast({
        title: "Error",
        description: "Debes iniciar sesión para comentar",
        variant: "destructive",
      });
      return;
    }

    addCommentMutation.mutate(newComment.trim());
  };

  const handleCancelComment = () => {
    setNewComment("");
    setIsCommenting(false);
  };

  return (
    <div className="p-4 overflow-y-auto">
      <h3 className="text-lg font-semibold mb-4 text-white">
        Comentarios ({comments?.length || 0})
      </h3>
      
      {/* Add Comment */}
      <div className="mb-6">
        <form onSubmit={handleSubmitComment}>
          <div className="flex space-x-3">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40&face"
              alt="Your avatar"
              className="w-8 h-8 rounded-full object-cover flex-shrink-0"
            />
            <div className="flex-1">
              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onFocus={() => setIsCommenting(true)}
                placeholder="Añade un comentario..."
                className="w-full bg-transparent border-b border-[hsl(240,3.7%,15.9%)] focus:border-white outline-none resize-none text-white"
                rows={isCommenting ? 3 : 2}
                disabled={addCommentMutation.isPending}
              />
              {isCommenting && (
                <div className="flex justify-end space-x-2 mt-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleCancelComment}
                    className="text-[hsl(0,0%,66.7%)] hover:text-white"
                    disabled={addCommentMutation.isPending}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                    disabled={addCommentMutation.isPending || !newComment.trim()}
                  >
                    {addCommentMutation.isPending ? "Publicando..." : "Comentar"}
                  </Button>
                </div>
              )}
            </div>
          </div>
        </form>
      </div>

      {/* Comments List */}
      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex space-x-3 animate-pulse">
              <div className="w-8 h-8 bg-[hsl(240,3.7%,15.9%)] rounded-full"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-[hsl(240,3.7%,15.9%)] rounded w-1/4"></div>
                <div className="h-3 bg-[hsl(240,3.7%,15.9%)] rounded w-3/4"></div>
                <div className="h-3 bg-[hsl(240,3.7%,15.9%)] rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      ) : comments && comments.length > 0 ? (
        <div className="space-y-4">
          {comments.map((comment) => (
            <div key={comment.id} className="flex space-x-3">
              <img
                src={comment.user?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40&face"}
                alt={comment.user?.name || "User"}
                className="w-8 h-8 rounded-full object-cover flex-shrink-0"
              />
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="font-medium text-sm text-white">
                    {comment.user?.name || "Usuario desconocido"}
                  </span>
                  <span className="text-[hsl(0,0%,66.7%)] text-xs">
                    {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true, locale: es })}
                  </span>
                </div>
                <p className="text-sm text-white mb-2">{comment.content}</p>
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center space-x-1 text-[hsl(0,0%,66.7%)] hover:text-white p-0 h-auto"
                  >
                    <ThumbsUp className="h-3 w-3" />
                    <span className="text-xs">{comment.likes}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-[hsl(0,0%,66.7%)] hover:text-white text-xs p-0 h-auto"
                  >
                    Responder
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-[hsl(0,0%,66.7%)]">No hay comentarios aún</p>
          <p className="text-sm text-[hsl(0,0%,66.7%)] mt-1">Sé el primero en comentar</p>
        </div>
      )}
    </div>
  );
}
