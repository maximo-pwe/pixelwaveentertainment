import { Home, TrendingUp, Music, Gamepad2, Video, Clock, ThumbsUp, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

interface SidebarProps {
  isOpen: boolean;
  onChannelSettingsClick: () => void;
}

export default function Sidebar({ isOpen, onChannelSettingsClick }: SidebarProps) {
  return (
    <nav 
      className={`fixed left-0 top-14 h-full w-64 bg-[hsl(240,10%,3.9%)] border-r border-[hsl(240,3.7%,15.9%)] transform transition-transform duration-300 z-40 overflow-y-auto ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      <div className="p-4 space-y-2">
        {/* Main Navigation */}
        <div className="space-y-1 mb-6">
          <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
            <Home className="h-5 w-5 mr-3" />
            Inicio
          </Button>
          <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
            <TrendingUp className="h-5 w-5 mr-3" />
            Tendencias
          </Button>
          <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
            <Music className="h-5 w-5 mr-3" />
            Música
          </Button>
          <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
            <Gamepad2 className="h-5 w-5 mr-3" />
            Gaming
          </Button>
        </div>

        <Separator className="bg-[hsl(240,3.7%,15.9%)]" />

        {/* User Content */}
        <div className="pt-4 mb-6">
          <h3 className="text-sm font-semibold text-[hsl(0,0%,66.7%)] mb-2 px-3">Tu Canal</h3>
          <div className="space-y-1">
            <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
              <Video className="h-5 w-5 mr-3" />
              Tus videos
            </Button>
            <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
              <Clock className="h-5 w-5 mr-3" />
              Ver más tarde
            </Button>
            <Button variant="ghost" className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]">
              <ThumbsUp className="h-5 w-5 mr-3" />
              Videos que te gustaron
            </Button>
          </div>
        </div>

        <Separator className="bg-[hsl(240,3.7%,15.9%)]" />

        {/* Settings */}
        <div className="pt-4">
          <Button 
            variant="ghost" 
            className="w-full justify-start text-white hover:bg-[hsl(240,3.7%,15.9%)]"
            onClick={onChannelSettingsClick}
          >
            <Settings className="h-5 w-5 mr-3" />
            Configurar Canal
          </Button>
        </div>
      </div>
    </nav>
  );
}
