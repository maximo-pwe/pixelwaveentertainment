import { useQuery } from "@tanstack/react-query";
import VideoCard from "./VideoCard";
import { Skeleton } from "@/components/ui/skeleton";

interface Video {
  id: number;
  title: string;
  description?: string;
  thumbnail?: string;
  cloudUrl: string;
  views: number;
  duration?: string;
  createdAt: Date;
  channel: {
    id: number;
    name: string;
    avatar?: string;
  } | null;
}

export default function VideoGrid() {
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-red-500 mb-2">Error al cargar los videos</p>
          <p className="text-sm text-gray-400">Por favor, intenta de nuevo más tarde</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="space-y-3">
            <Skeleton className="h-48 w-full rounded-lg" />
            <div className="flex space-x-3">
              <Skeleton className="h-9 w-9 rounded-full" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-gray-400 mb-2">No hay videos disponibles</p>
          <p className="text-sm text-gray-500">Sé el primero en subir un video</p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {videos.map((video) => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
}
