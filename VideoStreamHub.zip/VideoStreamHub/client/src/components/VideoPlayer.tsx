import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, Volume2, VolumeX, Maximize, X, ThumbsUp, ThumbsDown } from "lucide-react";
import CommentSection from "./CommentSection";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

interface Video {
  id: number;
  title: string;
  description?: string;
  thumbnail?: string;
  cloudUrl: string;
  views: number;
  likes: number;
  dislikes: number;
  duration?: string;
  createdAt: Date;
  channel: {
    id: number;
    name: string;
    avatar?: string;
  } | null;
}

interface VideoPlayerProps {
  video: Video | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function VideoPlayer({ video, isOpen, onClose }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (isOpen && video) {
      setCurrentTime(0);
      setIsPlaying(false);
    }
  }, [isOpen, video]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (value: number[]) => {
    if (videoRef.current) {
      videoRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    if (videoRef.current) {
      videoRef.current.volume = value[0];
      setVolume(value[0]);
      setIsMuted(value[0] === 0);
    }
  };

  const formatTime = (time: number): string => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const formatViews = (views: number): string => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K`;
    }
    return views.toString();
  };

  const showControlsTemporarily = () => {
    setShowControls(true);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 3000);
  };

  if (!video) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-none w-full h-full p-0 bg-black">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex justify-between items-center p-4 bg-[hsl(240,10%,3.9%)]">
            <h2 className="text-xl font-semibold text-white truncate pr-4">{video.title}</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-white hover:text-red-500 flex-shrink-0"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>

          <div className="flex-1 flex lg:flex-row flex-col">
            {/* Video Player */}
            <div className="lg:flex-1 bg-black relative">
              <div className="relative w-full h-0 pb-[56.25%]">
                <video
                  ref={videoRef}
                  src={video.cloudUrl}
                  className="absolute inset-0 w-full h-full object-contain"
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onMouseMove={showControlsTemporarily}
                  onClick={togglePlay}
                />
                
                {/* Video Controls */}
                <div 
                  className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4 transition-opacity duration-300 ${
                    showControls ? 'opacity-100' : 'opacity-0'
                  }`}
                  onMouseMove={showControlsTemporarily}
                >
                  {/* Progress Bar */}
                  <div className="mb-4">
                    <Slider
                      value={[currentTime]}
                      max={duration}
                      step={1}
                      onValueChange={handleSeek}
                      className="w-full"
                    />
                  </div>
                  
                  {/* Control Buttons */}
                  <div className="flex items-center space-x-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={togglePlay}
                      className="text-white hover:text-red-500"
                    >
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={toggleMute}
                        className="text-white hover:text-red-500"
                      >
                        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                      </Button>
                      <Slider
                        value={[isMuted ? 0 : volume]}
                        max={1}
                        step={0.1}
                        onValueChange={handleVolumeChange}
                        className="w-20"
                      />
                    </div>
                    
                    <span className="text-white text-sm">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                    
                    <div className="flex-1" />
                    
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-white hover:text-red-500"
                    >
                      <Maximize className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Video Info */}
              <div className="p-4 bg-[hsl(240,10%,3.9%)]">
                <h3 className="text-xl font-semibold mb-2 text-white">{video.title}</h3>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <img 
                      src={video.channel?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50&face"} 
                      alt={video.channel?.name || "Canal"}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-medium text-white">{video.channel?.name || "Canal desconocido"}</p>
                      <p className="text-[hsl(0,0%,66.7%)] text-sm">125K suscriptores</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Button variant="secondary" size="sm" className="flex items-center space-x-2">
                      <ThumbsUp className="h-4 w-4" />
                      <span>{video.likes}</span>
                    </Button>
                    <Button variant="secondary" size="sm" className="flex items-center space-x-2">
                      <ThumbsDown className="h-4 w-4" />
                      <span>{video.dislikes}</span>
                    </Button>
                    <Button className="bg-red-600 hover:bg-red-700 text-white">
                      Suscribirse
                    </Button>
                  </div>
                </div>
                <div className="bg-[hsl(240,3.7%,15.9%)] p-4 rounded-lg">
                  <p className="text-sm text-[hsl(0,0%,66.7%)] mb-2">
                    {formatViews(video.views)} visualizaciones • {formatDistanceToNow(new Date(video.createdAt), { addSuffix: true, locale: es })}
                  </p>
                  <p className="text-sm text-white">{video.description}</p>
                </div>
              </div>
            </div>

            {/* Comments Section */}
            <div className="lg:w-96 bg-[hsl(240,10%,3.9%)]">
              <CommentSection videoId={video.id} />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
