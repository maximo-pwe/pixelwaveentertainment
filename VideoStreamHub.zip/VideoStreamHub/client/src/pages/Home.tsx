import { useState, useEffect } from "react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import VideoGrid from "@/components/VideoGrid";
import VideoPlayer from "@/components/VideoPlayer";
import UploadModal from "@/components/UploadModal";
import LoginModal from "@/components/LoginModal";
import ChannelModal from "@/components/ChannelModal";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { signInWithGoogle, signInAsGuest, handleRedirectResult, onAuthStateChange } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface Video {
  id: number;
  title: string;
  description?: string;
  thumbnail?: string;
  cloudUrl: string;
  views: number;
  likes: number;
  dislikes: number;
  duration?: string;
  createdAt: Date;
  channel: {
    id: number;
    name: string;
    avatar?: string;
  } | null;
}

interface Channel {
  id: number;
  name: string;
  description?: string;
  avatar?: string;
}

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isChannelModalOpen, setIsChannelModalOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const { toast } = useToast();

  // Get user's channel when user is available
  const { data: userChannel } = useQuery<Channel>({
    queryKey: ["/api/channels/user", currentUser?.id],
    enabled: !!currentUser?.id,
  });

  useEffect(() => {
    // Handle Firebase auth redirect
    handleRedirectResult().then((user) => {
      if (user) {
        setCurrentUser(user);
        toast({
          title: "Bienvenido",
          description: `Hola ${user.name}!`,
        });
      }
    });

    // Listen for auth state changes
    const unsubscribe = onAuthStateChange((firebaseUser) => {
      if (!firebaseUser && currentUser && !currentUser.isGuest) {
        setCurrentUser(null);
        toast({
          title: "Sesión cerrada",
          description: "Has cerrado sesión exitosamente",
        });
      }
    });

    return () => unsubscribe();
  }, [currentUser, toast]);

  useEffect(() => {
    // Handle responsive sidebar
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(true);
      } else {
        setIsSidebarOpen(false);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleMenuToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleLoginClick = () => {
    if (currentUser) {
      // Show user menu or profile
      console.log("Show user menu");
    } else {
      setIsLoginModalOpen(true);
    }
  };

  const handleUploadClick = () => {
    if (!currentUser) {
      setIsLoginModalOpen(true);
    } else {
      setIsUploadModalOpen(true);
    }
  };

  const handleChannelSettingsClick = () => {
    if (!currentUser) {
      setIsLoginModalOpen(true);
    } else {
      setIsChannelModalOpen(true);
    }
  };

  const handleGoogleSignIn = () => {
    signInWithGoogle();
  };

  const handleGuestSignIn = async () => {
    try {
      const guestUser = await signInAsGuest();
      setCurrentUser(guestUser);
      setIsLoginModalOpen(false);
      toast({
        title: "Bienvenido como invitado",
        description: "Puedes explorar y subir videos como usuario invitado",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo iniciar sesión como invitado",
        variant: "destructive",
      });
    }
  };

  const handleVideoClick = (video: Video) => {
    setSelectedVideo(video);
  };

  return (
    <div className="min-h-screen bg-[hsl(240,10%,3.9%)] text-white">
      <Header
        onMenuToggle={handleMenuToggle}
        onLoginClick={handleLoginClick}
        onUploadClick={handleUploadClick}
        user={currentUser}
      />

      <Sidebar
        isOpen={isSidebarOpen}
        onChannelSettingsClick={handleChannelSettingsClick}
      />

      <main className={`pt-14 transition-all duration-300 ${isSidebarOpen ? 'lg:ml-64' : ''}`}>
        {/* Upload Section */}
        <div className="bg-[hsl(240,3.7%,15.9%)] border-b border-[hsl(240,3.7%,15.9%)] p-4">
          <div className="max-w-7xl mx-auto">
            <Button
              onClick={handleUploadClick}
              className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white"
            >
              <Plus className="h-4 w-4" />
              <span>Subir Video</span>
            </Button>
          </div>
        </div>

        {/* Video Grid */}
        <div className="max-w-7xl mx-auto p-4">
          <VideoGrid onVideoClick={handleVideoClick} />
        </div>
      </main>

      {/* Modals */}
      <VideoPlayer
        video={selectedVideo}
        isOpen={!!selectedVideo}
        onClose={() => setSelectedVideo(null)}
      />

      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        userChannelId={userChannel?.id}
      />

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onGoogleSignIn={handleGoogleSignIn}
        onGuestSignIn={handleGuestSignIn}
      />

      <ChannelModal
        isOpen={isChannelModalOpen}
        onClose={() => setIsChannelModalOpen(false)}
        userId={currentUser?.id}
      />
    </div>
  );
}
