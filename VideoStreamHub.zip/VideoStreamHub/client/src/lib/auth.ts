import { auth } from "./firebase";
import { 
  signInWithRedirect, 
  getRedirectResult, 
  GoogleAuthProvider, 
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser 
} from "firebase/auth";
import { apiRequest } from "./queryClient";

const provider = new GoogleAuthProvider();

export interface AppUser {
  id: number;
  email: string;
  name: string;
  avatar?: string;
  isGuest: boolean;
  firebaseUid?: string;
}

export function signInWithGoogle() {
  return signInWithRedirect(auth, provider);
}

export async function handleRedirectResult(): Promise<AppUser | null> {
  try {
    const result = await getRedirectResult(auth);
    if (result?.user) {
      return await createOrGetUser(result.user, false);
    }
    return null;
  } catch (error) {
    console.error("Error handling redirect result:", error);
    return null;
  }
}

export async function signInAsGuest(): Promise<AppUser> {
  const guestId = Date.now().toString();
  const guestUser = {
    email: `guest-${guestId}@example.com`,
    name: `Usuario Invitado ${guestId.slice(-4)}`,
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&face",
    isGuest: true,
  };

  const response = await apiRequest("POST", "/api/users", guestUser);
  return await response.json();
}

export async function signOut() {
  try {
    await firebaseSignOut(auth);
  } catch (error) {
    console.error("Error signing out:", error);
  }
}

export function onAuthStateChange(callback: (user: FirebaseUser | null) => void) {
  return onAuthStateChanged(auth, callback);
}

async function createOrGetUser(firebaseUser: FirebaseUser, isGuest: boolean): Promise<AppUser> {
  const userData = {
    email: firebaseUser.email || "",
    name: firebaseUser.displayName || "Usuario",
    avatar: firebaseUser.photoURL || undefined,
    isGuest,
  };

  const response = await apiRequest("POST", "/api/users", userData);
  return await response.json();
}
