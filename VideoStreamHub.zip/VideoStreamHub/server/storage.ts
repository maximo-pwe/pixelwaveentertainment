import { users, channels, videos, comments, type User, type Channel, type Video, type Comment, type InsertUser, type InsertChannel, type InsertVideo, type InsertComment } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;

  // Channel operations
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelByUserId(userId: number): Promise<Channel | undefined>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: number, updates: Partial<InsertChannel>): Promise<Channel | undefined>;

  // Video operations
  getVideo(id: number): Promise<Video | undefined>;
  getVideosByChannelId(channelId: number): Promise<Video[]>;
  getAllVideos(): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, updates: Partial<InsertVideo>): Promise<Video | undefined>;
  incrementVideoViews(id: number): Promise<void>;

  // Comment operations
  getComment(id: number): Promise<Comment | undefined>;
  getCommentsByVideoId(videoId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  updateComment(id: number, updates: Partial<InsertComment>): Promise<Comment | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private channels: Map<number, Channel>;
  private videos: Map<number, Video>;
  private comments: Map<number, Comment>;
  private currentUserId: number;
  private currentChannelId: number;
  private currentVideoId: number;
  private currentCommentId: number;

  constructor() {
    this.users = new Map();
    this.channels = new Map();
    this.videos = new Map();
    this.comments = new Map();
    this.currentUserId = 1;
    this.currentChannelId = 1;
    this.currentVideoId = 1;
    this.currentCommentId = 1;

    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample users
    const sampleUser1 = this.createUserSync({
      email: "tech@example.com",
      name: "TechChannel Pro",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&face",
      isGuest: false,
    });

    const sampleUser2 = this.createUserSync({
      email: "cooking@example.com",
      name: "Cocina Deliciosa",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&face",
      isGuest: false,
    });

    // Create sample channels
    const channel1 = this.createChannelSync({
      userId: sampleUser1.id,
      name: "TechChannel Pro",
      description: "Canal dedicado a la tecnología y programación.",
      avatar: sampleUser1.avatar,
    });

    const channel2 = this.createChannelSync({
      userId: sampleUser2.id,
      name: "Cocina Deliciosa",
      description: "Recetas auténticas y deliciosas.",
      avatar: sampleUser2.avatar,
    });

    // Create sample videos
    this.createVideoSync({
      channelId: channel1.id,
      title: "Tutorial de JavaScript Avanzado",
      description: "En este tutorial aprenderemos conceptos avanzados de JavaScript incluyendo closures, promises y async/await.",
      thumbnail: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
      cloudUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      duration: "15:47",
    });

    this.createVideoSync({
      channelId: channel2.id,
      title: "Receta Pasta Italiana Auténtica",
      description: "Aprende a hacer pasta italiana auténtica desde cero con ingredientes frescos.",
      thumbnail: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
      cloudUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      duration: "12:30",
    });
  }

  private createUserSync(insertUser: InsertUser): User {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      avatar: insertUser.avatar || null,
      isGuest: insertUser.isGuest || false,
      firebaseUid: insertUser.firebaseUid || null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  private createChannelSync(insertChannel: InsertChannel): Channel {
    const id = this.currentChannelId++;
    const channel: Channel = {
      ...insertChannel,
      id,
      avatar: insertChannel.avatar || null,
      description: insertChannel.description || null,
      createdAt: new Date(),
    };
    this.channels.set(id, channel);
    return channel;
  }

  private createVideoSync(insertVideo: InsertVideo): Video {
    const id = this.currentVideoId++;
    const video: Video = {
      ...insertVideo,
      id,
      description: insertVideo.description || null,
      thumbnail: insertVideo.thumbnail || null,
      duration: insertVideo.duration || null,
      views: 0,
      likes: 0,
      dislikes: 0,
      createdAt: new Date(),
    };
    this.videos.set(id, video);
    return video;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    return this.createUserSync(insertUser);
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getChannel(id: number): Promise<Channel | undefined> {
    return this.channels.get(id);
  }

  async getChannelByUserId(userId: number): Promise<Channel | undefined> {
    return Array.from(this.channels.values()).find(channel => channel.userId === userId);
  }

  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    return this.createChannelSync(insertChannel);
  }

  async updateChannel(id: number, updates: Partial<InsertChannel>): Promise<Channel | undefined> {
    const channel = this.channels.get(id);
    if (!channel) return undefined;
    
    const updatedChannel = { ...channel, ...updates };
    this.channels.set(id, updatedChannel);
    return updatedChannel;
  }

  async getVideo(id: number): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async getVideosByChannelId(channelId: number): Promise<Video[]> {
    return Array.from(this.videos.values()).filter(video => video.channelId === channelId);
  }

  async getAllVideos(): Promise<Video[]> {
    return Array.from(this.videos.values());
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    return this.createVideoSync(insertVideo);
  }

  async updateVideo(id: number, updates: Partial<InsertVideo>): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;
    
    const updatedVideo = { ...video, ...updates };
    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }

  async incrementVideoViews(id: number): Promise<void> {
    const video = this.videos.get(id);
    if (video) {
      video.views = (video.views || 0) + 1;
      this.videos.set(id, video);
    }
  }

  async getComment(id: number): Promise<Comment | undefined> {
    return this.comments.get(id);
  }

  async getCommentsByVideoId(videoId: number): Promise<Comment[]> {
    return Array.from(this.comments.values()).filter(comment => comment.videoId === videoId);
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const comment: Comment = {
      id,
      content: insertComment.content,
      userId: insertComment.userId,
      videoId: insertComment.videoId,
      parentId: insertComment.parentId || null,
      likes: 0,
      createdAt: new Date(),
    };
    this.comments.set(id, comment);
    return comment;
  }

  async updateComment(id: number, updates: Partial<InsertComment>): Promise<Comment | undefined> {
    const comment = this.comments.get(id);
    if (!comment) return undefined;
    
    const updatedComment = { ...comment, ...updates };
    this.comments.set(id, updatedComment);
    return updatedComment;
  }
}

export const storage = new MemStorage();
