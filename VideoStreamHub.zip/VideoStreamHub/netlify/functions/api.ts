import { Handler } from '@netlify/functions';
import { storage } from '../../server/storage';
import { insertUserSchema, insertChannelSchema, insertVideoSchema, insertCommentSchema } from '../../shared/schema';
import { z } from 'zod';

const handler: Handler = async (event, context) => {
  const { path, httpMethod, body, queryStringParameters } = event;
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  // Handle OPTIONS requests for CORS
  if (httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  try {
    const parsedBody = body ? JSON.parse(body) : {};
    
    // Route handling
    if (path === '/api/videos' && httpMethod === 'GET') {
      const videos = await storage.getAllVideos();
      const videosWithChannels = await Promise.all(
        videos.map(async (video) => {
          const channel = await storage.getChannel(video.channelId);
          return {
            ...video,
            channel: channel ? {
              id: channel.id,
              name: channel.name,
              avatar: channel.avatar,
            } : null,
          };
        })
      );
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(videosWithChannels),
      };
    }
    
    if (path?.match(/^\/api\/videos\/\d+$/) && httpMethod === 'GET') {
      const id = parseInt(path.split('/')[3]);
      const video = await storage.getVideo(id);
      
      if (!video) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: 'Video not found' }),
        };
      }
      
      const channel = await storage.getChannel(video.channelId);
      await storage.incrementVideoViews(id);
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          ...video,
          views: (video.views || 0) + 1,
          channel: channel ? {
            id: channel.id,
            name: channel.name,
            avatar: channel.avatar,
          } : null,
        }),
      };
    }
    
    if (path === '/api/videos' && httpMethod === 'POST') {
      const videoData = insertVideoSchema.parse(parsedBody);
      const video = await storage.createVideo(videoData);
      
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify(video),
      };
    }
    
    if (path === '/api/users' && httpMethod === 'POST') {
      const userData = insertUserSchema.parse(parsedBody);
      
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(existingUser),
        };
      }
      
      const user = await storage.createUser(userData);
      
      await storage.createChannel({
        userId: user.id,
        name: user.name,
        description: `Canal de ${user.name}`,
        avatar: user.avatar,
      });
      
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify(user),
      };
    }
    
    if (path?.match(/^\/api\/channels\/user\/\d+$/) && httpMethod === 'GET') {
      const userId = parseInt(path.split('/')[4]);
      const channel = await storage.getChannelByUserId(userId);
      
      if (!channel) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: 'Channel not found' }),
        };
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(channel),
      };
    }
    
    if (path?.match(/^\/api\/channels\/\d+$/) && httpMethod === 'PUT') {
      const id = parseInt(path.split('/')[3]);
      const channel = await storage.updateChannel(id, parsedBody);
      
      if (!channel) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: 'Channel not found' }),
        };
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(channel),
      };
    }
    
    if (path?.match(/^\/api\/videos\/\d+\/comments$/) && httpMethod === 'GET') {
      const videoId = parseInt(path.split('/')[3]);
      const comments = await storage.getCommentsByVideoId(videoId);
      
      const commentsWithUsers = await Promise.all(
        comments.map(async (comment) => {
          const user = await storage.getUser(comment.userId);
          return {
            ...comment,
            user: user ? {
              id: user.id,
              name: user.name,
              avatar: user.avatar,
            } : null,
          };
        })
      );
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(commentsWithUsers),
      };
    }
    
    if (path === '/api/comments' && httpMethod === 'POST') {
      const commentData = insertCommentSchema.parse(parsedBody);
      const comment = await storage.createComment(commentData);
      
      const user = await storage.getUser(comment.userId);
      
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
          ...comment,
          user: user ? {
            id: user.id,
            name: user.name,
            avatar: user.avatar,
          } : null,
        }),
      };
    }

    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ message: 'Route not found' }),
    };
    
  } catch (error) {
    console.error('Function error:', error);
    
    if (error instanceof z.ZodError) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: 'Invalid data', errors: error.errors }),
      };
    }
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
};

export { handler };